package phase1programs_4;

import java.util.Scanner;

public class P1LinearSearch { 
	
public static int linearSearch(int[] arr, int key){
	
        for(int i=0;i<arr.length;i++)
        {    
            if(arr[i] == key)
            {    
                return i;    
            }    
        }    
        return -1;    
    }    
   
public static void main(String a[]){    
        int[] arr = {50, 100, 150, 200, 250, 300};    
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the element to be searched");
        int key = sc.nextInt();
        
        System.out.println(key+" is found at index: " + linearSearch(arr, key));    
    }    
}    
