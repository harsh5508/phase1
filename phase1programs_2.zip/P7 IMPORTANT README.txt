For P7Read path specified - d://P7//P7FileRead.txt
For P7Update path specified - d://P7//P7FileUpdate.txt
For P7Delete path specified - d://P7//P7FileDelete.txt

Above Mentioned Txt Files are also provided along with the project.