package package4;

import package3.*;

public class PublicAccSpec extends PublicClass {

public static void main(String[] args) {
		
		PublicAccSpec obj = new PublicAccSpec(); 
        obj.display();  

    } 

}


