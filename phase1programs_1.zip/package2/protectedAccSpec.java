package package2;

import package1.*;

public class protectedAccSpec extends protectedclass {

	public static void main(String[] args) {
		
			protectedAccSpec obj = new protectedAccSpec ();   
		       obj.display();  
	}

}
