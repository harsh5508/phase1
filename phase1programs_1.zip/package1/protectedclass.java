package package1;

public class protectedclass {

	
		protected void display() 
	    { 
	        System.out.println("This is protected access specifier"); 
	    } 

	}


